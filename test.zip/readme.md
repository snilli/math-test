# How to run 
```
npx tsx a.ts
```